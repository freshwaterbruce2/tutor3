export { default } from './WordSearchGame';
