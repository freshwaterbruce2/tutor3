import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig, loadEnv } from 'vite';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, '.', '');
  return {
    plugins: [react()],
    define: {
      'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY ?? process.env.GEMINI_API_KEY ?? ''),
      'process.env.API_KEY': JSON.stringify(env.GEMINI_API_KEY ?? process.env.API_KEY ?? ''),
    },
    base: mode === 'development' ? '/' : './',
    build: {
      minify: 'esbuild',
      sourcemap: false,
      rollupOptions: {
        output: {
          manualChunks(id) {
            if (!id.includes('node_modules')) return undefined;
            if (id.includes('@react-spring')) return 'vendor-spring';
            if (id.includes('lucide-react')) return 'vendor-icons';
            if (/[\\/]node_modules[\\/](react|react-dom|scheduler)[\\/]/.test(id)) return 'vendor-react';
            if (id.includes('@capacitor') || id.includes('jeep-sqlite')) return 'vendor-capacitor';
            return 'vendor-misc';
          },
        },
      },
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, './src'),
        '@vibetech/avatars': path.resolve(__dirname, './packages/avatars/src/index.ts'),
        '@vibetech/games/tutor': path.resolve(__dirname, './packages/games/src/tutor/index.ts'),
        '@vibetech/games': path.resolve(__dirname, './packages/games/src/index.ts'),
      },
    },
    server: {
      proxy: {
        '/api': {
          target: 'http://localhost:3001',
          changeOrigin: true,
        },
      },
    },
  };
});
